# DBT Scholarship Portal
React project for DBT-enabled Aadhaar scholarship awareness.